let n = 20;
while (n < 100) {
    n *= 2;
}
console.log(n); 