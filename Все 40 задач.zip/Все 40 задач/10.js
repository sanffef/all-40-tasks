let num = 15;
if (num >= 10 && num <= 20) {
    console.log("В диапазоне");
}