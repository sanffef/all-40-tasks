let str = "";
if (str === "") {
    console.log("Пусто");
} else {
    console.log("Текст есть");
}