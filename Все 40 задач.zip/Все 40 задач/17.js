let grade = 4;
if (grade === 5) {
    console.log("Отлично");
} else if (grade === 4) {
    console.log("Хорошо");
} else {
    console.log("Старайся");
}