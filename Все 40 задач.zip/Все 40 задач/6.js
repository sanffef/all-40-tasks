let a = 10;
let b = 15;
let c = {
    if (a > b);
    console.log(a)
}else{
    if (a < b);
    console.log(b)
}