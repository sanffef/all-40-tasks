let result = "";
for (let i = 5; i >= 1; i--) {
    result += i + " ";
}
console.log(result.trim());