let a = -5;{
    if(a < 0);
    console.log("Минус");
}else{
    if(a > 0);
    console.log("Плюс")
}else{
    if(a = 0);
    console.log(0)
}