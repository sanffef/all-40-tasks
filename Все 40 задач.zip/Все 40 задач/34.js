let a = 1, b = 7, c = 5;
if (a === 7 || b === 7 || c === 7) {
    console.log("Все ок");
}