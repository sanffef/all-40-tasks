let result = "";
for (let i = 1; i <= 10; i++) {
    result += (2 * i) + " ";
}
console.log(result.trim());