let result = "";
for (let i = 1; i <= 4; i++) {
    result += (i * i) + " ";
}
console.log(result.trim());