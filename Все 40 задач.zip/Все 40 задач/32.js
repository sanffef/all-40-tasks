let t = 10;
if (t < 0) {
    console.log("Мороз");
} else if (t > 25) {
    console.log("Жара");
} else {
    console.log("Нормально");
}