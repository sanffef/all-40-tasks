let word = "арбуз";
if (word[0].toLowerCase() === "а") {
    console.log("Начинается на А");
}