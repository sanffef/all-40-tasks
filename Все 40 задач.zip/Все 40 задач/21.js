let n = 3;
let sum = 0;
for (let i = 1; i <= n; i++) {
    sum += i;
}
console.log(sum);