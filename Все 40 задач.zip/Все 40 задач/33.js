let str = "Пи";
console.log(`${str}${str}`);