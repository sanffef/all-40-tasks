let word = "Кот";
if (word.length > 5) {
    console.log("Длинное");
} else {
    console.log("Короткое");
}