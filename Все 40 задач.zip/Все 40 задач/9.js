let a = 2;
let b = 3;
let res = a + b;

console.log(`Сумма ${a} и ${b} равна ${res}`);