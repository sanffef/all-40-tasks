let word = "Python";
console.log(`Первая буква: ${word[0]}`);