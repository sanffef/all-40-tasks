let name = "Алекс";

console.log(`Привет, ${name}!`);