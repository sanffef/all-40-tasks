let name = "Иван";
let job = "кодер";

console.log(`${name} — это отличный ${job}!`);