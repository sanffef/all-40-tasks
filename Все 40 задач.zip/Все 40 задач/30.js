let login = "user";
if (login !== "admin") {
    console.log("Доступ запрещен");
}