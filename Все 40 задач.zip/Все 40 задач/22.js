let evens = "";
for (let i = 2; i <= 10; i += 2) {
    evens += i + " ";
}
console.log(evens.trim());