let a = 3, b = 10;
let res = Math.max(a, b) - Math.min(a, b);

console.log(res);