let word = "банан";
if (word.includes("а")) {
    console.log("Найдена");
}