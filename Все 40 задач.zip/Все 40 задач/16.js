let price = 1200;
let finalPrice = price > 1000 ? price * 0.9 : price;
console.log(finalPrice.toFixed(1));