var a = 5;
let result = a * a;
console.log(result);