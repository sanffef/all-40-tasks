let day = "понедельник";
if (day === "суббота" || day === "воскресенье") {
    console.log("Выходной");
} else {
    console.log("Работа");
}