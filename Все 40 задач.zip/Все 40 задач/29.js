let num1 = 4, num2 = 6;
let avg = (num1 + num2) / 2;
console.log(avg.toFixed(1));