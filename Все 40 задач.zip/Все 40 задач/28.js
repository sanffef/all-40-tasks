let N = 3;
let countdown = "";
while (N >= 0) {
    countdown += N + " ";
    N--;
}
console.log(countdown.trim());