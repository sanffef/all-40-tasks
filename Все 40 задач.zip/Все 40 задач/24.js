while (true) {
    let input = prompt("Введите слово:"); 
    if (input === "стоп") {
        break;
    }
}