const age = 17;{
if(age > 18)
    console.log("Доступ разрешен");
}else{
    console.log("Маловат еще")
}