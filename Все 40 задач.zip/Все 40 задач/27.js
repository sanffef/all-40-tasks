let a = 3, b = 4;
if (a > 0 && b > 0) {
    console.log(a * b);
}