let num = 9;
if (num % 3 === 0) {
    console.log("Да");
}