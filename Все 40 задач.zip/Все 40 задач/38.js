let num = 7;
if (num === 7) {
    console.log("Счастливое число!");
} else {
    console.log("Обычное число");
}