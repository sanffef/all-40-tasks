let n = 7;
console.log(`Результат: ${n * 10}`);