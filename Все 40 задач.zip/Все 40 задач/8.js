let words = "123";{
    if (words = "python123")
        console.log("Верно");
}else{
    console.log("Ошибка");
}