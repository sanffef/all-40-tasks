let num = 10;
if (num % 2 === 0 && num % 5 === 0) {
    console.log("Подходит");
}