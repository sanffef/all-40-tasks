let val = 0;
if (!val) {
    console.log("Это ноль");
}